<?php
	header('Location: /index.php?g=Wap&m=Yeepay&a=return_url&data='.$_GET['data'].'&encryptkey='.$_GET['encryptkey']);
?>