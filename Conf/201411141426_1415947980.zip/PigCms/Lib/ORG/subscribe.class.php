<?php
class subscribe {
	public function __construct($token,$wecha_id,$data,$siteurl){
		
		$this->token=$token;
	}
	public function sub(){
		
	}
	public function unsub(){
		
	}
}
